// File: Models/ApiModels.cs
// Bug-Free C# DTOs matching PHP 8.5 / Laravel 13.35 API (MANUAL_TESTING.md)
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace LotteryAdmin.Portal.Models;

public sealed record ApiEnvelope<T>(
    [property: JsonPropertyName("status")] int Status,
    [property: JsonPropertyName("message")] string Message,
    [property: JsonPropertyName("data")] T? Data
);

public sealed record WalletDto(
    // Intentional backend spelling preserved: "avaliableBalance"
    [property: JsonPropertyName("avaliableBalance")] string AvaliableBalance,
    [property: JsonPropertyName("lockedAmount")] string LockedAmount
);

public sealed record DepositCreateRequest(
    [property: JsonPropertyName("amount")] string Amount,
    [property: JsonPropertyName("lastSixTranId")] string LastSixTranId,
    // Capitalized field names required by POST /api/payment/deposit
    [property: JsonPropertyName("PaymentAccountId")] Guid PaymentAccountId,
    [property: JsonPropertyName("PaymentMethodId")] Guid PaymentMethodId,
    [property: JsonPropertyName("clientReference")] Guid ClientReference
);

public sealed record PaymentStatusPatchRequest(
    [property: JsonPropertyName("status")] string Status,
    [property: JsonPropertyName("lastSixTranId")] string? LastSixTranId = null
);

public sealed record OddsSettingRequest(
    [property: JsonPropertyName("name")] string Name,
    [property: JsonPropertyName("oddNumber")] string OddNumber,
    [property: JsonPropertyName("payoutMode")] string PayoutMode // "total" or "profit"
);

public sealed record BetEntryDto(
    [property: JsonPropertyName("number")] string Number, // Fixed-width "05" or "007"
    [property: JsonPropertyName("stakeAmount")] string StakeAmount
);

public sealed record PlaceBetBatchRequest(
    [property: JsonPropertyName("drawDate")] string DrawDate,
    [property: JsonPropertyName("timeType")] string TimeType, // "am" or "pm"
    [property: JsonPropertyName("clientReference")] Guid ClientReference,
    [property: JsonPropertyName("entries")] IReadOnlyList<BetEntryDto> Entries
);

public sealed record RecordResultRequest(
    [property: JsonPropertyName("drawDate")] string DrawDate,
    [property: JsonPropertyName("timeType")] string TimeType,
    [property: JsonPropertyName("winningNumber")] string WinningNumber,
    [property: JsonPropertyName("name")] string Name
);

public sealed record SessionQueryRequest(
    [property: JsonPropertyName("drawDate")] string DrawDate,
    [property: JsonPropertyName("timeType")] string TimeType
);

public sealed record PayoutPreviewResponse(
    [property: JsonPropertyName("totalBets")] int TotalBets,
    [property: JsonPropertyName("winnersCount")] int WinnersCount,
    [property: JsonPropertyName("totalStake")] string TotalStake,
    [property: JsonPropertyName("totalPayout")] string TotalPayout,
    [property: JsonPropertyName("previewToken")] string PreviewToken // 64-char token
);

public sealed record SettleResultRequest(
    [property: JsonPropertyName("drawDate")] string DrawDate,
    [property: JsonPropertyName("timeType")] string TimeType,
    [property: JsonPropertyName("previewToken")] string PreviewToken
);

public sealed record CancelSessionRequest(
    [property: JsonPropertyName("drawDate")] string DrawDate,
    [property: JsonPropertyName("timeType")] string TimeType,
    [property: JsonPropertyName("reason")] string Reason
);