// File: Services/LotteryAdminApiClient.cs
// Typed HttpClient Service for Blazor WebAssembly communicating with Laravel 13.35 API
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Threading;
using System.Threading.Tasks;
using LotteryAdmin.Portal.Models;

namespace LotteryAdmin.Portal.Services;

public sealed class LotteryAdminApiClient
{
    private readonly HttpClient _http;

    public LotteryAdminApiClient(HttpClient http)
    {
        _http = http;
    }

    public void SetBearerToken(string accessToken)
    {
        _http.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", accessToken);
    }

    // 1. Approve or Reject Deposit (PATCH /api/admin/payment/deposit/{id}/status)
    public async Task<HttpResponseMessage> ReviewDepositAsync(
        Guid transactionId, string status, CancellationToken ct = default)
    {
        var payload = new PaymentStatusPatchRequest(Status: status);
        return await _http.PatchAsJsonAsync(
            $"api/admin/payment/deposit/{transactionId}/status", payload, ct);
    }

    // 2. Approve or Decline Withdrawal (PATCH /api/admin/payment/withdrawal/{id}/status)
    public async Task<HttpResponseMessage> ReviewWithdrawalAsync(
        Guid withdrawalId, string status, string? lastSixTranId = null, CancellationToken ct = default)
    {
        var payload = new PaymentStatusPatchRequest(Status: status, LastSixTranId: lastSixTranId);
        return await _http.PatchAsJsonAsync(
            $"api/admin/payment/withdrawal/{withdrawalId}/status", payload, ct);
    }

    // 3. Append New Immutable Odds Setting (POST /api/admin/{game}/odds)
    public async Task<HttpResponseMessage> CreateOddsSettingAsync(
        string game, OddsSettingRequest request, CancellationToken ct = default)
    {
        return await _http.PostAsJsonAsync($"api/admin/{game}/odds", request, ct);
    }

    // 4. Record Winning Number (POST /api/admin/{game}/results)
    public async Task<HttpResponseMessage> RecordWinningNumberAsync(
        string game, RecordResultRequest request, CancellationToken ct = default)
    {
        return await _http.PostAsJsonAsync($"api/admin/{game}/results", request, ct);
    }

    // 5. Generate 64-Character Payout Preview Token (POST /api/admin/{game}/results/preview)
    public async Task<ApiEnvelope<PayoutPreviewResponse>?> PreviewPayoutAsync(
        string game, string drawDate, string timeType, CancellationToken ct = default)
    {
        var response = await _http.PostAsJsonAsync(
            $"api/admin/{game}/results/preview",
            new SessionQueryRequest(drawDate, timeType), ct);

        response.EnsureSuccessStatusCode();
        return await response.Content.ReadFromJsonAsync<ApiEnvelope<PayoutPreviewResponse>>(cancellationToken: ct);
    }

    // 6. Confirm Settlement with Mandatory previewToken (POST /api/admin/{game}/results/settle)
    public async Task<HttpResponseMessage> SettleSessionAsync(
        string game, SettleResultRequest request, CancellationToken ct = default)
    {
        return await _http.PostAsJsonAsync($"api/admin/{game}/results/settle", request, ct);
    }

    // 7. Cancel Unpaid Session & Refund Entries (POST /api/admin/{game}/results/cancel)
    public async Task<HttpResponseMessage> CancelSessionAsync(
        string game, CancelSessionRequest request, CancellationToken ct = default)
    {
        return await _http.PostAsJsonAsync($"api/admin/{game}/results/cancel", request, ct);
    }
}