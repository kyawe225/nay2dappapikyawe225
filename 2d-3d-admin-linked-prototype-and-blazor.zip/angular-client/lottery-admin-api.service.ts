// File: src/app/core/services/lottery-admin-api.service.ts
// Modern Angular (v19+) Injectable Service using HttpClient & Signals for the PHP 8.5 API
import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface WalletState {
  avaliableBalance: string; // Matches exact PHP API property name
  lockedAmount: string;
}

export interface PayoutPreviewDto {
  totalBets: number;
  winnersCount: number;
  totalStake: string;
  totalPayout: string;
  previewToken: string;
}

@Injectable({ providedIn: 'root' })
export class LotteryAdminApiService {
  private readonly http = inject(HttpClient);
  private readonly baseUrl = 'http://127.0.0.1:8000/api';

  readonly wallet = signal<WalletState>({ avaliableBalance: '0.00', lockedAmount: '0.00' });

  async approveDeposit(transactionId: string): Promise<unknown> {
    return firstValueFrom(
      this.http.patch(`${this.baseUrl}/admin/payment/deposit/${transactionId}/status`, {
        status: 'approved',
      })
    );
  }

  async approveWithdrawal(withdrawalId: string, lastSixTranId: string): Promise<unknown> {
    return firstValueFrom(
      this.http.patch(`${this.baseUrl}/admin/payment/withdrawal/${withdrawalId}/status`, {
        status: 'approved',
        lastSixTranId,
      })
    );
  }

  async previewAndSettleSession(game: 'twod' | 'threed', drawDate: string, timeType: 'am' | 'pm') {
    const previewRes = await firstValueFrom(
      this.http.post<{ status: number; data: PayoutPreviewDto }>(
        `${this.baseUrl}/admin/${game}/results/preview`,
        { drawDate, timeType }
      )
    );
    const previewToken = previewRes.data.previewToken;
    return firstValueFrom(
      this.http.post(`${this.baseUrl}/admin/${game}/results/settle`, {
        drawDate,
        timeType,
        previewToken,
      })
    );
  }
}